#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "que.h"
#include "media.h"
#include "songs.h"
// #include "video.h"

using namespace std;

int main()
{
  srand(time(0));
  que();
  cout << endl;
  return 0;
}