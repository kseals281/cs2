#ifndef SONGS
#define SONGS

#include "media.h"

class song: public media
{
public:
  song();
  void display();
};

#endif