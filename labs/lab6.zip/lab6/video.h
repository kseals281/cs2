#ifndef VIDEO
#define VIDEO

#include "media.h"

class video: public media
{
public:
  video();
  void display();
};

#endif